//
//  LZBaseTableViewCell.h
//  LZAccount
//
//  Created by Artron_LQQ on 16/5/25.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LZBaseTableViewCell : UITableViewCell

@end
