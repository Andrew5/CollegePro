//
//  LZSettingTableViewCell.h
//  LZAccount
//
//  Created by Artron_LQQ on 16/6/1.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LZSettingTableViewCell : UITableViewCell

@end
