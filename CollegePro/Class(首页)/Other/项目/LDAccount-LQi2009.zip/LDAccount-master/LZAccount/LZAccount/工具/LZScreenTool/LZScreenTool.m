//
//  LZScreenTool.m
//  LZAccount
//
//  Created by Artron_LQQ on 2016/10/21.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import "LZScreenTool.h"

@implementation LZScreenTool

@end
