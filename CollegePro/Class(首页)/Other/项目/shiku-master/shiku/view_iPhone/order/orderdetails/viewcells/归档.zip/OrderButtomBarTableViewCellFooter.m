//
//  CartTableViewCellFooter.m
//  shiku
//
//  Created by txj on 15/5/11.
//  Copyright (c) 2015年 txj. All rights reserved.
//

#import "OrderButtomBarTableViewCellFooter.h"

@implementation OrderButtomBarTableViewCellFooter

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.*/
- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGRect cellRect = self.frame;
    CGContextSetFillColorWithColor(context, BG_COLOR.CGColor);
    CGContextFillRect(context, CGRectMake(0, 0, cellRect.size.width, cellRect.size.height));
    
    self.btnQFK.layer.cornerRadius=5;
    [self.btnQFK setTintColor:MAIN_COLOR];
    self.btnQFK.layer.borderColor=MAIN_COLOR.CGColor;
    self.btnQFK.layer.borderWidth=1;
    
    self.btnTXFH.layer.cornerRadius=5;
    [self.btnTXFH setTintColor:TEXT_COLOR_DARK];
    self.btnTXFH.layer.borderColor=TEXT_COLOR_DARK.CGColor;
    self.btnTXFH.layer.borderWidth=1;
    
    self.btnQRSH.layer.cornerRadius=5;
    [self.btnQRSH setTintColor:MAIN_COLOR];
    self.btnQRSH.layer.borderColor=MAIN_COLOR.CGColor;
    self.btnQRSH.layer.borderWidth=1;
    
    self.btnCKWL.layer.cornerRadius=5;
    [self.btnCKWL setTintColor:TEXT_COLOR_DARK];
    self.btnCKWL.layer.borderColor=TEXT_COLOR_DARK.CGColor;
    self.btnCKWL.layer.borderWidth=1;
    
    self.btnSCDD.layer.cornerRadius=5;
    [self.btnSCDD setTintColor:TEXT_COLOR_DARK];
    self.btnSCDD.layer.borderColor=TEXT_COLOR_DARK.CGColor;
    self.btnSCDD.layer.borderWidth=1;

}
- (void)bind
{
    @weakify(self)
    [RACObserve(self, order)
     subscribeNext:^(id x) {
         @strongify(self);
         [self render];
     }];
}

- (void)unbind
{
}
-(void)render
{
    if ([self.order.order_info.order_status isEqualToString:@"0"]) {
        [self.btnQFK setHidden:NO];
        [self.btnTXFH setHidden:YES];
        [self.btnCKWL setHidden:YES];
        [self.btnQRSH setHidden:YES];
        [self.btnSCDD setHidden:YES];
    }
    else if ([self.order.order_info.order_status isEqualToString:@"1"]) {
        [self.btnQFK setHidden:YES];
        [self.btnTXFH setHidden:NO];
        [self.btnCKWL setHidden:YES];
        [self.btnQRSH setHidden:YES];
        [self.btnSCDD setHidden:YES];
    }
    else if ([self.order.order_info.order_status isEqualToString:@"2"]) {
        [self.btnQFK setHidden:YES];
        [self.btnTXFH setHidden:YES];
        [self.btnCKWL setHidden:NO];
        [self.btnQRSH setHidden:NO];
        [self.btnSCDD setHidden:YES];
    }
    else {
        [self.btnQFK setHidden:YES];
        [self.btnTXFH setHidden:YES];
        [self.btnCKWL setHidden:NO];
        [self.btnQRSH setHidden:YES];
        [self.btnSCDD setHidden:NO];
    }

}
//确认收货
- (IBAction)btnQRSHTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(didQRSHTaped:)])
    {
        [self.delegate didQRSHTaped:self.order];
    }
}
//查看物流
- (IBAction)btnCKWLTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(didCKWLTaped:)])
    {
        [self.delegate didCKWLTaped:self.order];
    }
}
//提醒发货
- (IBAction)btnTXFHTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(didCKXQTapped:)])
    {
        [self.delegate didCKXQTapped:self.order];
    }
}
//去付款
- (IBAction)btnQFKTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(didQFKTaped:)])
    {
        [self.delegate didQFKTaped:self.order];
    }
}
//删除订单
- (IBAction)btnSCDDTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(didSCDDTaped:)])
    {
        [self.delegate didQRSHTaped:self.order];
    }
}
@end
