//
//  CartTableViewCellFooter.h
//  shiku
//
//  Created by txj on 15/5/11.
//  Copyright (c) 2015年 txj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderListTableViewCellFooter.h"

@interface OrderButtomBarTableViewCellFooter : TUITableViewHeaderFooterView

@property (weak, nonatomic) IBOutlet UIButton *btnQRSH;
@property (weak, nonatomic) IBOutlet UIButton *btnCKWL;
@property (weak, nonatomic) IBOutlet UIButton *btnTXFH;
@property (weak, nonatomic) IBOutlet UIButton *btnQFK;
@property (weak, nonatomic) IBOutlet UIButton *btnSCDD;

- (IBAction)btnQRSHTapped:(id)sender;
- (IBAction)btnCKWLTapped:(id)sender;
- (IBAction)btnTXFHTapped:(id)sender;
- (IBAction)btnQFKTapped:(id)sender;
- (IBAction)btnSCDDTapped:(id)sender;

@property (strong, nonatomic) id<OrderListTableViewCellFooterDelegate> delegate;
@property (strong, nonatomic) ORDER *order;
@end
