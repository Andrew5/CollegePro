//
//  NextDirectionEnum.swift
//  ARBottleJump
//
//  Created by 宋 奎熹 on 2018/1/4.
//  Copyright © 2018年 宋 奎熹. All rights reserved.
//

enum NextDirection: Int {
    case left       = 0
    case right      = 1
}
