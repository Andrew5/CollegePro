//
//  CoordinateTests.m
//  CoordinateTests
//
//  Created by Corrine Chan on 3/9/13.
//  Copyright (c) 2013 Corrine Chan. All rights reserved.
//

#import "CoordinateTests.h"

@implementation CoordinateTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in CoordinateTests");
}

@end
