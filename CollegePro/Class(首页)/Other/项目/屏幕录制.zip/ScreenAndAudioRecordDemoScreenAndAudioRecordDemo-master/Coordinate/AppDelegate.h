//
//  AppDelegate.h
//  Coordinate
//
//  Created by Corrine Chan on 3/9/13.
//  Copyright (c) 2013 Corrine Chan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
