# ScreenAndAudioRecordDemoScreenAndAudioRecordDemo
录制屏幕操作，同时录制声音，合成视频存入相册
PS: 白板绘制代码用的之前一个工程里的，没有做大的改动，只是为了展示下屏幕和音频录制的功能
    工程中使用了THCapture，感谢wayne li
    

