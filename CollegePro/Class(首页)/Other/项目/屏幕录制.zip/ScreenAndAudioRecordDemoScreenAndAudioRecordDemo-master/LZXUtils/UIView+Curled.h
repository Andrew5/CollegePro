//
//  UIView+Curled.h
//  lexue-teacher
//
//  Created by 白冰 on 13-7-19.
//  Copyright (c) 2013年 白冰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Curled)
-(void)setborderWidth:(CGFloat)borderWidth shadowDepth:(CGFloat)shadowHeight controlPointXOffset:(CGFloat)controlPointXOffset controlPointYOffset:(CGFloat)controlPointYOffset;
@end
