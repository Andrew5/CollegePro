//
//  ViewController.m
//  TabViewMultiselect
//
//  Created by mac on 16/9/5.
//  Copyright © 2016年 zrgg. All rights reserved.
//

#import "ViewController.h"
#import "UIView+Addition.h"

#define SWIDTH [UIScreen mainScreen].bounds.size.width
#define SHEIGHT [UIScreen mainScreen].bounds.size.height

#define CellHeight 44

@implementation MyModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    _isOpen = NO;
    _isSelect = NO;
}

@end


@implementation MyTableCell





-(void)awakeFromNib{
    _lineView.top = 42.5;
    _lineView.height = 0.5;
}

@end

@interface ViewController ()
{
    NSMutableArray *dataSource;
    UIView *headView;
    BOOL isOpenAll;
    UIButton *selectAllCell;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    isOpenAll = NO;
    headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SWIDTH, CellHeight)];
    _myTabView.tableHeaderView = headView;


    UIView *tt = [self createHeadView];
    tt.backgroundColor = [UIColor colorWithRed:0.8708 green:0.9146 blue:0.7781 alpha:1.0];
    [headView addSubview:tt];
   selectAllCell = [tt viewWithTag:2];
    [selectAllCell addTarget:self action:@selector(selectAllBtnClick:) forControlEvents:UIControlEventTouchUpInside];

    UIButton *openBtn = [tt viewWithTag:3];
    [openBtn addTarget:self action:@selector(openAll:) forControlEvents:UIControlEventTouchUpInside];

    UILabel *titleLabel = [tt viewWithTag:1];
    titleLabel.text = @"全部";
    titleLabel.font = [UIFont boldSystemFontOfSize:16];
    titleLabel.left = 5;


    _myTabView.tableFooterView = [[UIView alloc]init];

    dataSource = [NSMutableArray array];

    NSArray *tempData = @[@{@"title":@"二级标题0",@"list":@[@{@"title":@"三级标题01",
                              @"list":@[
  @{@"title":@"商品1"},
  @{@"title":@"商品1"},
  @{@"title":@"商品2"},
  @{@"title":@"商品3" }]},@{@"title":@"三级标题02",
                          @"list":@[
                                  @{@"title":@"商品10"},
                                  @{@"title":@"商品01"},
                                  @{@"title":@"商品20"},
                                  @{@"title":@"商品30" }]}
                                                     ]}
                          ,@{@"title":@"二级标题1",@"list":@[@{@"title":@"三级标题11",
                                                                                     @"list":@[
                                                                                             @{@"title":@"肉类1"},
                                                                                             @{@"title":@"肉类1"},
                                                                                             @{@"title":@"肉类2"},
                                                                                             @{@"title":@"肉类3" }]}
                                                                                   ]}];

    for (NSInteger i = 0; i < tempData.count; i ++) {
        NSArray *array = tempData[i][@"list"];
         MyModel *model11 = [[MyModel alloc]init];
        [model11 setValuesForKeysWithDictionary:tempData[i]];
         NSMutableArray *data2 = [NSMutableArray array];
        for (NSInteger j = 0; j< array.count; j ++) {
            NSArray *arr = array[j][@"list"];
             MyModel *model1 = [[MyModel alloc]init];
            [model1 setValuesForKeysWithDictionary:array[j]];
             NSMutableArray *data1 = [NSMutableArray array];
            for (NSInteger t = 0; t < arr.count; t ++) {
                    MyModel *model = [[MyModel alloc]init];
                    [model setValuesForKeysWithDictionary:arr[t]];
                    [data1 addObject:model];
            }
            model1.list = data1;
            [data2 addObject:model1];
        }
        model11.list = data2;
        [dataSource addObject:model11];
    }

}

- (void)openAll:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected==YES) {
        isOpenAll = YES;
    }else{
        isOpenAll = NO;
    }
    [_myTabView reloadData];
}

- (void)selectAllBtnClick:(UIButton *)sender{
    sender.selected = !sender.selected;

    for (NSInteger i = 0; i < dataSource.count; i ++) {

        MyModel *model11 = dataSource[i];
        model11.isSelect = sender.selected;
        for (NSInteger j = 0; j< model11.list.count; j ++) {
            MyModel *model1 = model11.list[j];
            model1.isSelect = sender.selected;;
            for (NSInteger t = 0; t < model1.list.count; t ++) {
                MyModel *model = model1.list[t];
                model.isSelect = sender.selected;;
            }

        }
    }

    [_myTabView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (isOpenAll) {
        return dataSource.count;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    MyModel *model = dataSource[section];
    if (model.isOpen) {
        return model.list.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    MyTableCell *cell = [tableView dequeueReusableCellWithIdentifier:@"myCell"];

    MyModel *model = dataSource[indexPath.section];
    MyModel *dicModel = model.list[indexPath.row];
    cell.titleLabel.text = dicModel.title;
    [cell.goodsView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    if (dicModel.isOpen) {
        cell.goodsView.height = dicModel.list.count*CellHeight;
         NSString *str = [NSString stringWithFormat:@"%d%d",indexPath.section+1,indexPath.row];
        for (NSInteger i = 0; i < dicModel.list.count; i++) {
            MyModel *tempModel = dicModel.list[i];
            UIView *view = [self createHeadView];
            view.top = i *CellHeight;
            view.tag = 500+i+[str integerValue]*100;



            UIButton *openBtn = [view viewWithTag:3];
            openBtn.hidden = YES;

            UIButton *sss = [view viewWithTag:2];
            [sss addTarget:self action:@selector(selectTempSingle:) forControlEvents:UIControlEventTouchUpInside];
            sss.selected = tempModel.isSelect;


            UILabel *titleLabel = [view viewWithTag:1];
            titleLabel.left = 30;
            titleLabel.text = tempModel.title;
//            titleLabel.text = [NSString stringWithFormat:@"%d", view.tag];
            titleLabel.font = [UIFont systemFontOfSize:13];
            titleLabel.textColor = [UIColor colorWithRed:0.4229 green:0.4229 blue:0.4229 alpha:1.0];
            [cell.goodsView addSubview:view];
        }
    }else{
        cell.goodsView.height = 0;
    }

    cell.secondSelectBtn.selected = dicModel.isSelect;
    cell.isOpenSelectBtn.selected = dicModel.isOpen;

    [cell.secondSelectBtn addTarget:self action:@selector(CellHeadSelectClick:) forControlEvents:UIControlEventTouchUpInside];

    [cell.isOpenSelectBtn addTarget:self action:@selector(CellOpenBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

- (void)CellHeadSelectClick:(UIButton *)sender {
    sender.selected = !sender.selected;
    UITableViewCell *cell = (UITableViewCell *)sender.superview.superview;
    NSIndexPath *indexPath = [_myTabView indexPathForCell:cell];
    MyModel *model = dataSource[indexPath.section];
    MyModel *dicModel = model.list[indexPath.row];
    dicModel.isSelect = sender.selected;
    for (NSInteger i = 0; i < dicModel.list.count; i ++) {
         MyModel *tempModel = dicModel.list[i];
        tempModel.isSelect = sender.selected;
    }
    if (sender.selected==NO) {
        selectAllCell.selected = NO;
        model.isSelect = NO;

    }else{
        NSInteger count = 0;
        for (NSInteger i = 0; i< dataSource.count; i ++) {
            MyModel *tempModel1 = dataSource[i];
             NSInteger count1 = 0;
            for (NSInteger j = 0; j< tempModel1.list.count; j ++) {
                MyModel *tempModel2 = tempModel1.list[j];
                if (tempModel2.isSelect) {
                    count1++;
                }
            }
            if (count1==tempModel1.list.count) {
                tempModel1.isSelect = YES;
            }
            if (tempModel1.isSelect) {
                count++;
            }

        }
        if (count==dataSource.count) {
            selectAllCell.selected = YES;
        }


    }
    NSIndexSet *indexset = [NSIndexSet indexSetWithIndex:indexPath.section];
    [_myTabView reloadSections:indexset withRowAnimation:UITableViewRowAnimationFade];

}

- (void)CellOpenBtnClick:(UIButton *)sender {
   sender.selected = !sender.selected;
    UITableViewCell *cell = (UITableViewCell *)sender.superview.superview;
    NSIndexPath *indexPath = [_myTabView indexPathForCell:cell];
    MyModel *model = dataSource[indexPath.section];
    MyModel *dicModel = model.list[indexPath.row];
    dicModel.isOpen = sender.selected;
    [_myTabView reloadData];
//    if (sender.selected==YES) {
//        [_myTabView setContentOffset:CGPointMake(0, _myTabView.contentOffset.y+dicModel.list.count/2*44) animated:YES];
//    }else{
//       [_myTabView setContentOffset:CGPointMake(0, MAX(0, _myTabView.contentOffset.y-dicModel.list.count/2*44)) animated:YES];
//    }

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    MyModel *model = dataSource[indexPath.section];
    MyModel *dicModel = model.list[indexPath.row];
    if (dicModel.isOpen) {
        return 44 + dicModel.list.count*44;
    }else{
        return 44;
    }
    return 44;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    UIView *tt = [self createHeadView];
    tt.tag =  100+section;



    UIButton *openBtn = [tt viewWithTag:3];
    [openBtn addTarget:self action:@selector(openBtnTempAll:) forControlEvents:UIControlEventTouchUpInside];

    UIButton *sss = [tt viewWithTag:2];
    [sss addTarget:self action:@selector(sectionSlectTap:) forControlEvents:UIControlEventTouchUpInside];


    UILabel *titleLabel = [tt viewWithTag:1];
    titleLabel.left = 15;
    titleLabel.font = [UIFont systemFontOfSize:15];

    MyModel *model = dataSource[section];
    titleLabel.text =model.title;
    openBtn.selected = model.isOpen;
    sss.selected = model.isSelect;



    return tt;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return CellHeight;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.1;
}


- (void)sectionSlectTap:(UIButton *)sender{
    sender.selected = !sender.selected;

    UIView *view = sender.superview;
    MyModel *model = dataSource[view.tag-100];
    model.isSelect = sender.selected;
        for (NSInteger j = 0; j< model.list.count; j ++) {
            MyModel *model1 = model.list[j];
            model1.isSelect = sender.selected;;
            for (NSInteger t = 0; t < model1.list.count; t ++) {
                MyModel *model = model1.list[t];
                model.isSelect = sender.selected;;
            }

        }
    if (sender.selected==NO) {
        selectAllCell.selected = NO;
    }else{
        NSInteger count = 0;
        for (NSInteger j = 0; j< dataSource.count; j ++) {
             MyModel *model = dataSource[j];
            if (model.isSelect) {
                count++;
            }
        }
        if (count==dataSource.count) {
             selectAllCell.selected = YES;
        }
    }
    NSIndexSet *set = [NSIndexSet indexSetWithIndex:view.tag-100];
    [_myTabView reloadSections:set withRowAnimation:UITableViewRowAnimationFade];




}


- (void)openBtnTempAll:(UIButton *)sender{
    sender.selected = !sender.selected;
    UIView *view = sender.superview;
     MyModel *model = dataSource[view.tag-100];
    model.isOpen = sender.selected;

    NSIndexSet *set = [NSIndexSet indexSetWithIndex:view.tag-100];
    [_myTabView reloadSections:set withRowAnimation:UITableViewRowAnimationFade];
}


- (void)selectTempSingle:(UIButton *)sender{
    sender.selected = !sender.selected;
    UITableViewCell *cell = (UITableViewCell *)sender.superview.superview.superview.superview;
    NSIndexPath *indexPath = [_myTabView indexPathForCell:cell];
    MyModel *model = dataSource[indexPath.section];
    MyModel *dicModel = model.list[indexPath.row];
    NSString *str = [NSString stringWithFormat:@"%ld%ld",(long)indexPath.section+1,(long)indexPath.row];
    NSInteger index = sender.superview.tag-500-[str integerValue]*100;

    MyModel *thhreeModel = dicModel.list[index];
    thhreeModel.isSelect = sender.selected ;
    if (sender.selected==NO) {
        selectAllCell.selected = NO;
        model.isSelect = NO;
        dicModel.isSelect = NO;
    }else{
         NSInteger count = 0;
        for (NSInteger i = 0; i< dataSource.count; i ++) {
            MyModel *tempModel1 = dataSource[i];
             NSInteger count1 = 0;
            for (NSInteger j = 0; j< tempModel1.list.count; j ++) {
                MyModel *tempModel2 = tempModel1.list[j];
                 NSInteger count2 = 0;
                for (NSInteger t = 0; t < tempModel2.list.count; t ++) {
                    MyModel *tempModel3 = tempModel2.list[t];
                    if (tempModel3.isSelect) {
                        count2++;
                    }
                }
                if (count2==tempModel2.list.count) {
                    tempModel2.isSelect = YES;
                }
                if (tempModel2.isSelect) {
                    count1++;
                }
            }
            if (count1==tempModel1.list.count) {
                tempModel1.isSelect = YES;
            }
            if (tempModel1.isSelect) {
                count++;
            }

        }
        if (count==dataSource.count) {
            selectAllCell.selected = YES;
        }
    }


    NSIndexSet *indexset = [NSIndexSet indexSetWithIndex:indexPath.section];
    [_myTabView reloadSections:indexset withRowAnimation:UITableViewRowAnimationFade];


}

- (UIView *)createHeadView{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SWIDTH, CellHeight)];
    view.backgroundColor = [UIColor whiteColor];

    UILabel *titlae = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, SWIDTH-10*2-70, view.height)];
    titlae.font = [UIFont systemFontOfSize:14];
    titlae.tag = 1;
    [view addSubview:titlae];


    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, SWIDTH-70, view.height)];
    btn.tag = 3;

    [view addSubview:btn];


    UIButton *btn1 = [[UIButton alloc]initWithFrame:CGRectMake(SWIDTH-70, 0, 60, view.height)];
    btn1.tag = 2;
    btn1.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [btn1 setImage:[UIImage imageNamed:@"normal"] forState:UIControlStateNormal];
    [btn1 setImage:[UIImage imageNamed:@"selected"] forState:UIControlStateSelected];
    [view addSubview:btn1];

    UIView *label = [[UIView alloc]initWithFrame:CGRectMake(0, view.height-0.5, SWIDTH, 0.5)];
    [view addSubview:label];
    label.backgroundColor = [UIColor colorWithRed:0.7333 green:0.7294 blue:0.749 alpha:1.0];



    return view;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
