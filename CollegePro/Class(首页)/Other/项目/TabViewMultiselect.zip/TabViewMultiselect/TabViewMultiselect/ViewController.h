//
//  ViewController.h
//  TabViewMultiselect
//
//  Created by mac on 16/9/5.
//  Copyright © 2016年 zrgg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyModel : NSObject

@property (nonatomic , copy)NSString *title;
@property (nonatomic , retain)NSArray *list;
@property (nonatomic , assign)BOOL isOpen;
@property (nonatomic , assign)BOOL isSelect;

@end


@interface MyTableCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *goodsView;
@property (weak, nonatomic) IBOutlet UIButton *secondSelectBtn;
@property (nonatomic , assign)BOOL isGoodSelect;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UIButton *isOpenSelectBtn;

@property (weak, nonatomic) IBOutlet UIView *lineView;

- (IBAction)SecondSelectBtnClick:(UIButton *)sender;

- (IBAction)isOpenSelectBtnClick:(UIButton *)sender;



@end


@interface ViewController : UIViewController<UITableViewDelegate , UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *myTabView;



@end

