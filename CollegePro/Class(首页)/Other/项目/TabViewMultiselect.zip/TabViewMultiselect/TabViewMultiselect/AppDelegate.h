//
//  AppDelegate.h
//  TabViewMultiselect
//
//  Created by mac on 16/9/5.
//  Copyright © 2016年 zrgg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

